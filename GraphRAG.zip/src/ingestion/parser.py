"""
Swagger Graph Builder for Kubernetes YAML Configuration Generation
===================================================================
Implements 4-Pass Architecture (+ 2.5) for safe, cycle-free graph construction.

SCOPE:
    ✅ Ingest: definitions (K8s resource schemas for YAML)
       ├─ Properties & $ref (Pass 2)
       ├─ allOf/oneOf/anyOf inheritance (Pass 2.5)
       └─ Semantic YAML patterns (Pass 3)
    
    ❌ Skip: paths (HTTP API specs - handled by kubectl)

Edge Ontology (7 Categories):
    1. Structural: HAS_PROPERTY, EXTENDS, ONE_OF, ANY_OF
    2. Workload: CONTAINS_POD_TEMPLATE, CONTAINS_JOB_TEMPLATE, HAS_CONTAINER
    3. Storage: CLAIMS_VOLUME, MOUNTS_VOLUME, USES_STORAGE_CLASS
    4. Configuration: LOADS_CONFIGMAP, USES_SECRET
    5. Networking: SELECTS_POD, ROUTES_TRAFFIC_TO
    6. RBAC: BINDS_ROLE, BINDS_SERVICE_ACCOUNT, USES_SERVICE_ACCOUNT
    7. Autoscaling: SCALES_RESOURCE

Usage:
    parser = SwaggerGraphBuilder(swagger_path)
    parser.ingest()
"""

import json
import os
from typing import Dict, Any, List
from datetime import datetime
from src.graph.neo4j_client import Neo4jClient
from src.utils.text_utils import safe_truncate_description


# ============================================
# CONSTANTS
# ============================================
PRIMITIVE_TYPES = {"string", "integer", "number", "boolean", "array", "object"}

IGNORE_LIST = {
    "io.k8s.apimachinery.pkg.apis.meta.v1.ManagedFieldsEntry",
    "io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta",
    "io.k8s.apimachinery.pkg.apis.meta.v1.StatusDetails",
    "io.k8s.apimachinery.pkg.apis.meta.v1.Time",
    "io.k8s.apimachinery.pkg.apis.meta.v1.MicroTime",
    "io.k8s.apimachinery.pkg.apis.meta.v1.Duration",
    "io.k8s.apimachinery.pkg.apis.meta.v1.RawExtension",
}


# ============================================
# MAIN CLASS
# ============================================
class SwaggerGraphBuilder:
    """
    Builds a Neo4j Knowledge Graph from Kubernetes Swagger/OpenAPI spec.
    
    Architecture:
        Pass 1: Create all Definition nodes (with robust GVK extraction)
        Pass 2: Create HAS_PROPERTY edges based on $ref (with metadata)
        Pass 2.5: Create inheritance edges (allOf/oneOf/anyOf)
        Pass 3: Create semantic edges (7-category YAML patterns)
    
    SCOPE: YAML Configuration Generation (Infrastructure as Code)
    """
    
    def __init__(self, swagger_path: str):
        self.swagger_path = swagger_path
        self.db = Neo4jClient()
        self.definitions: Dict[str, Any] = {}

    def load_swagger(self):
        """
        Loads the 5MB JSON file into memory.
        SCOPE: Only definitions (YAML schemas), NOT paths (HTTP API).
        """
        print(f"📂 Loading Swagger file: {self.swagger_path}")
        with open(self.swagger_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            # ✅ ONLY definitions (K8s resource schemas)
            self.definitions = data.get('definitions', {})
            # ❌ SKIP paths (HTTP API specs - handled by kubectl)
        
        print(f"   ✓ Loaded {len(self.definitions)} resource definitions")
        print(f"   ⚠️  Skipped HTTP paths (kubectl handles API execution)")

    def ingest(self):
        """
        Main entry point using the Enhanced 4-Pass Architecture (YAML-focused).
        """
        self.load_swagger()
        print()
        print(f"📊 Starting Ingestion: {len(self.definitions)} definitions")
        print(f"🎯 Scope: Kubernetes YAML Configuration (Infrastructure as Code)")
        print(f"📚 Edge Ontology: 7 categories (19 edge types)")
        print()

        # Clean database
        print("⚠️  Cleaning existing graph data...")
        self.db.execute_query("MATCH (n) DETACH DELETE n")
        print("   ✓ Database cleared")
        print()

        # Pass 1: Create Nodes
        print("--> Pass 1: Creating Resource Definition Nodes...")
        self._pass_1_create_nodes()
        print()

        # Pass 2: Create Structural Edges (properties + $ref)
        print("--> Pass 2: Resolving Schema Relationships...")
        self._pass_2_create_structural_edges()
        print()

        # Pass 2.5: Create Inheritance Edges (allOf/oneOf/anyOf)
        print("--> Pass 2.5: Resolving Inheritance & Union Types...")
        self._pass_2b_create_inheritance_edges()
        print()

        # Pass 3: Create Semantic Edges (YAML-focused)
        print("--> Pass 3: Extracting YAML Configuration Patterns...")
        self._pass_3_build_semantic_edges()
        print()

        # ❌ REMOVED: Pass 4 (API Endpoints - not needed for YAML generation)

        print("✅ Ingestion Complete! The Kubernetes YAML Graph is ready.")

    def _pass_1_create_nodes(self):
        """
        PASS 1: Create all Definition nodes.
        
        KEY FIX: Robust GVK extraction to fix kind='string' bug.
        The GVK structure in swagger is: [{'group': 'apps', 'kind': 'Deployment', 'version': 'v1'}]
        We need to extract the 'kind' field from the dict, not the type name.
        """
        created_count = 0
        skipped_count = 0
        
        # Debug: Track first 10 root resources to verify GVK extraction
        debug_printed = 0
        
        for full_name, schema in self.definitions.items():
            # Semantic Stop: Skip ignored definitions
            if full_name in IGNORE_LIST:
                skipped_count += 1
                continue

            # === 1. Basic Naming (Core Properties) ===
            short_name = full_name.split(".")[-1]

            # === 2. ROBUST GVK Extraction (CRITICAL FIX) ===
            gvk_list = schema.get("x-kubernetes-group-version-kind", [])
            is_root = False
            kind = short_name  # Default fallback
            
            # Only process if GVK exists and is a non-empty list
            if gvk_list and isinstance(gvk_list, list) and len(gvk_list) > 0:
                first_gvk = gvk_list[0]
                
                # Only extract if first_gvk is a dict (not a string or type object)
                if isinstance(first_gvk, dict):
                    # Safely get 'kind' value from the dict
                    kind_value = first_gvk.get('kind')
                    
                    # Only use if kind_value is a non-empty string
                    if isinstance(kind_value, str) and kind_value.strip():
                        kind = kind_value.strip()
                        is_root = True
                    else:
                        # GVK exists but kind is invalid, use short_name
                        kind = short_name
                        is_root = True
                else:
                    # GVK list item is not a dict, use short_name
                    kind = short_name
                    is_root = True
            else:
                # No GVK = sub-resource
                kind = "SubResource"
                is_root = False

            # Debug print first 10 root resources
            if is_root and debug_printed < 10:
                print(f"      [DEBUG] {short_name:35} kind='{kind}'")
                debug_printed += 1

            # === 3. Description Handling (Defensive Cap) ===
            original_desc = schema.get('description', 'No description provided.')
            desc = safe_truncate_description(original_desc, hard_limit=4000)
            original_length = len(original_desc)
            was_truncated = len(desc) < original_length

            # === 4. Create Node with MERGE (Idempotent) ===
            self.db.execute_query("""
                MERGE (d:Definition {id: $full_name})
                SET d.name = $short_name,
                    d.fullName = $full_name,
                    d.kind = $kind,
                    d.is_root = $is_root,
                    d.description = $desc,
                    d.description_length = $original_length,
                    d.was_truncated = $was_truncated,
                    d.source = 'k8s_swagger_v1'
            """, {
                "full_name": full_name,
                "short_name": short_name,
                "kind": kind,
                "is_root": is_root,
                "desc": desc,
                "original_length": original_length,
                "was_truncated": was_truncated
            })
            
            created_count += 1
            
            # Progress indicator every 500 nodes
            if created_count % 500 == 0:
                print(f"      Processed {created_count} definitions...")

        # Add K8sResource label to root resources
        self.db.execute_query("""
            MATCH (d:Definition {is_root: true})
            SET d:K8sResource
        """)
        
        print(f"   ✓ Created {created_count} nodes (skipped {skipped_count} ignored)")

    def _pass_2_create_structural_edges(self):
        """
        PASS 2: Read properties of each definition and map connections.
        Enhanced with edge metadata for YAML generation (is_array, is_required).
        """
        edge_count = 0
        primitive_count = 0
        
        for full_name, schema in self.definitions.items():
            if full_name in IGNORE_LIST:
                continue

            properties = schema.get('properties', {})
            # Track required fields for valid YAML generation
            required_fields = schema.get('required', [])
            primitive_props = {}

            for field_name, field_schema in properties.items():
                field_type = field_schema.get('type')
                ref = field_schema.get('$ref')
                is_array = False
                is_map = False
                is_required = field_name in required_fields

                # === 1. Handle Arrays of Refs ===
                if field_type == 'array' and 'items' in field_schema:
                    items = field_schema['items']
                    if isinstance(items, dict):
                        if '$ref' in items:
                            ref = items['$ref']
                            is_array = True
                        elif items.get('type') in PRIMITIVE_TYPES:
                            primitive_props[field_name] = f"array_of_{items.get('type')}"
                            primitive_count += 1
                            continue

                # === 2. Handle Maps/Dictionaries (additionalProperties) ===
                if field_type == 'object' and 'additionalProperties' in field_schema:
                    add_props = field_schema['additionalProperties']
                    if isinstance(add_props, dict):
                        if '$ref' in add_props:
                            ref = add_props['$ref']
                            is_map = True
                        elif add_props.get('type') in PRIMITIVE_TYPES:
                            primitive_props[field_name] = f"map_of_{add_props.get('type')}"
                            primitive_count += 1
                            continue

                # === 3. Semantic Stop: Primitive Truncation ===
                if field_type in PRIMITIVE_TYPES and not ref:
                    primitive_props[field_name] = field_type
                    primitive_count += 1
                
                # === 4. Structural Edge: $ref to another Definition ===
                elif ref:
                    target_name = ref.split("/")[-1]
                    if target_name not in IGNORE_LIST:
                        # Track is_array, is_map, is_required on edge
                        self.db.execute_query("""
                            MATCH (source:Definition {id: $source_id})
                            MATCH (target:Definition {id: $target_id})
                            MERGE (source)-[r:HAS_PROPERTY {name: $field_name}]->(target)
                            SET r.is_array = $is_array,
                                r.is_map = $is_map,
                                r.is_required = $is_required
                        """, {
                            "source_id": full_name,
                            "target_id": target_name,
                            "field_name": field_name,
                            "is_array": is_array,
                            "is_map": is_map,
                            "is_required": is_required
                        })
                        edge_count += 1

            # Batch update primitive properties
            if primitive_props:
                self.db.execute_query("""
                    MATCH (d:Definition {id: $full_name})
                    SET d += $primitive_props
                """, {
                    "full_name": full_name,
                    "primitive_props": primitive_props
                })

        print(f"   ✓ Created {edge_count} structural edges (HAS_PROPERTY)")
        print(f"   ✓ Stored {primitive_count} primitive properties")
        print(f"   ℹ️  Edge properties: is_array, is_map, is_required")

    def _pass_2b_create_inheritance_edges(self):
        """
        PASS 2.5: Create inheritance relationships from allOf/oneOf/anyOf.
        CRITICAL for Kubernetes schema understanding (e.g., Deployment extends ObjectMeta + DeploymentSpec).
        """
        inheritance_count = 0
        union_count = 0
        
        for full_name, schema in self.definitions.items():
            if full_name in IGNORE_LIST:
                continue
            
            # === 1. Handle allOf (Inheritance/Composition) ===
            all_of = schema.get('allOf', [])
            if isinstance(all_of, list):
                for item in all_of:
                    if isinstance(item, dict) and '$ref' in item:
                        ref = item['$ref']
                        parent_name = ref.split('/')[-1]
                        if parent_name not in IGNORE_LIST:
                            self.db.execute_query("""
                                MATCH (child:Definition {id: $child_id})
                                MATCH (parent:Definition {id: $parent_id})
                                MERGE (child)-[:EXTENDS]->(parent)
                            """, {
                                "child_id": full_name,
                                "parent_id": parent_name
                            })
                            inheritance_count += 1
            
            # === 2. Handle oneOf (Union Types - Important for Volumes, etc.) ===
            one_of = schema.get('oneOf', [])
            if isinstance(one_of, list):
                for item in one_of:
                    if isinstance(item, dict) and '$ref' in item:
                        ref = item['$ref']
                        option_name = ref.split('/')[-1]
                        if option_name not in IGNORE_LIST:
                            self.db.execute_query("""
                                MATCH (union:Definition {id: $union_id})
                                MATCH (option:Definition {id: $option_id})
                                MERGE (union)-[:ONE_OF]->(option)
                            """, {
                                "union_id": full_name,
                                "option_id": option_name
                            })
                            union_count += 1
            
            # === 3. Handle anyOf (Similar to oneOf but allows multiple) ===
            any_of = schema.get('anyOf', [])
            if isinstance(any_of, list):
                for item in any_of:
                    if isinstance(item, dict) and '$ref' in item:
                        ref = item['$ref']
                        option_name = ref.split('/')[-1]
                        if option_name not in IGNORE_LIST:
                            self.db.execute_query("""
                                MATCH (base:Definition {id: $base_id})
                                MATCH (option:Definition {id: $option_id})
                                MERGE (base)-[:ANY_OF]->(option)
                            """, {
                                "base_id": full_name,
                                "option_id": option_name
                            })
                            union_count += 1
        
        print(f"   ✓ Created {inheritance_count} inheritance edges (EXTENDS)")
        print(f"   ✓ Created {union_count} union edges (oneOf/anyOf)")

    def _pass_3_build_semantic_edges(self):
        """
        PASS 3: YAML Configuration Pattern Engine.
        7-Category Edge Ontology aligned with Kubernetes Official Documentation.
        """
        semantic_rules = [
            # ==================== 2. WORKLOAD EDGES ====================
            ("Deployment → PodTemplate", """
                MATCH (d:Definition {kind: 'Deployment'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'template'}]->(t)
                MERGE (d)-[:CONTAINS_POD_TEMPLATE]->(t)
            """),
            ("ReplicaSet → PodTemplate", """
                MATCH (rs:Definition {kind: 'ReplicaSet'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'template'}]->(t)
                MERGE (rs)-[:CONTAINS_POD_TEMPLATE]->(t)
            """),
            ("DaemonSet → PodTemplate", """
                MATCH (ds:Definition {kind: 'DaemonSet'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'template'}]->(t)
                MERGE (ds)-[:CONTAINS_POD_TEMPLATE]->(t)
            """),
            ("Job → PodTemplate", """
                MATCH (j:Definition {kind: 'Job'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'template'}]->(t)
                MERGE (j)-[:CONTAINS_POD_TEMPLATE]->(t)
            """),
            ("CronJob → JobTemplate", """
                MATCH (cj:Definition {kind: 'CronJob'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'jobTemplate'}]->(j)
                MERGE (cj)-[:CONTAINS_JOB_TEMPLATE]->(j)
            """),
            ("PodSpec → Container", """
                MATCH (p:Definition {id: 'io.k8s.api.core.v1.PodSpec'})-[:HAS_PROPERTY {name: 'containers'}]->(c)
                MERGE (p)-[:HAS_CONTAINER]->(c)
            """),

            # ==================== 3. STORAGE EDGES ====================
            ("StatefulSet → VolumeClaimTemplates", """
                MATCH (s:Definition {kind: 'StatefulSet'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'volumeClaimTemplates'}]->(pvc)
                MERGE (s)-[:CLAIMS_VOLUME]->(pvc)
            """),
            ("PodSpec → Volume", """
                MATCH (p:Definition {id: 'io.k8s.api.core.v1.PodSpec'})-[:HAS_PROPERTY {name: 'volumes'}]->(v)
                MERGE (p)-[:MOUNTS_VOLUME]->(v)
            """),
            ("PVC → StorageClass", """
                MATCH (pvc:Definition {kind: 'PersistentVolumeClaim'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'storageClassName'}]->(sc)
                MERGE (pvc)-[:USES_STORAGE_CLASS]->(sc)
            """),

            # ==================== 4. CONFIGURATION EDGES ====================
            ("Container → ConfigMap", """
                MATCH (c:Definition {id: 'io.k8s.api.core.v1.Container'})-[:HAS_PROPERTY {name: 'envFrom'}]->(e)
                MERGE (c)-[:LOADS_CONFIGMAP]->(e)
            """),
            ("PodSpec → Secret", """
                MATCH (p:Definition {id: 'io.k8s.api.core.v1.PodSpec'})-[:HAS_PROPERTY {name: 'imagePullSecrets'}]->(s)
                MERGE (p)-[:USES_SECRET]->(s)
            """),

            # ==================== 5. NETWORKING EDGES ====================
            ("Service → Pod Selector", """
                MATCH (svc:Definition {kind: 'Service'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'selector'}]->(sel)
                MERGE (svc)-[:SELECTS_POD]->(sel)
            """),
            ("Ingress → Service", """
                MATCH (i:Definition {kind: 'Ingress'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'rules'}]->(r)
                MERGE (i)-[:ROUTES_TRAFFIC_TO]->(r)
            """),

            # ==================== 6. RBAC EDGES ====================
            ("RoleBinding → Role", """
                MATCH (rb:Definition {kind: 'RoleBinding'})-[:HAS_PROPERTY {name: 'roleRef'}]->(r)
                MERGE (rb)-[:BINDS_ROLE]->(r)
            """),
            ("RoleBinding → ServiceAccount", """
                MATCH (rb:Definition {kind: 'RoleBinding'})-[:HAS_PROPERTY {name: 'subjects'}]->(sa)
                MERGE (rb)-[:BINDS_SERVICE_ACCOUNT]->(sa)
            """),
            ("PodSpec → ServiceAccount", """
                MATCH (p:Definition {id: 'io.k8s.api.core.v1.PodSpec'})-[:HAS_PROPERTY {name: 'serviceAccountName'}]->(sa)
                MERGE (p)-[:USES_SERVICE_ACCOUNT]->(sa)
            """),

            # ==================== 7. AUTOSCALING EDGES ====================
            ("HPA → Scale Target", """
                MATCH (h:Definition {kind: 'HorizontalPodAutoscaler'})-[:HAS_PROPERTY {name: 'spec'}]->(spec)
                MATCH (spec)-[:HAS_PROPERTY {name: 'scaleTargetRef'}]->(t)
                WHERE t.kind IN ['Deployment', 'StatefulSet', 'DaemonSet', 'ReplicaSet']
                MERGE (h)-[:SCALES_RESOURCE]->(t)
            """),
        ]

        executed_count = 0
        skipped_count = 0
        skipped_rules = []
        executed_rules = []
        
        print(f"   Executing {len(semantic_rules)} YAML pattern rules...")
        
        for rule_name, query in semantic_rules:
            try:
                self.db.execute_query(query)
                executed_count += 1
                executed_rules.append(rule_name)
                print(f"      ✓ {rule_name}")
            except Exception as e:
                skipped_count += 1
                skipped_rules.append({
                    "rule": rule_name,
                    "error": str(e)[:150]
                })
                print(f"      ⚠ {rule_name} - SKIPPED: {str(e)[:100]}")

        print()
        print(f"   ✓ Executed: {executed_count} rules")
        print(f"   ⚠ Skipped: {skipped_count} rules")
        
        if skipped_rules:
            print()
            print("   📋 Skipped Rules Detail:")
            for skip in skipped_rules:
                print(f"      • {skip['rule']}")
                print(f"        Reason: {skip['error']}")
        
        # Save to single log file (overwrite every run)
        report_path = "logs/semantic_rules_execution.log"
        os.makedirs("logs", exist_ok=True)
        
        report_data = {
            "timestamp": datetime.now().isoformat(),
            "scope": "YAML_IaC_ONLY",
            "total_rules": len(semantic_rules),
            "executed": executed_count,
            "skipped": skipped_count,
            "executed_rules": executed_rules,
            "skipped_rules": skipped_rules,
            "edge_ontology": {
                "category_1_structural": "HAS_PROPERTY, EXTENDS, ONE_OF, ANY_OF",
                "category_2_workload": "CONTAINS_POD_TEMPLATE, CONTAINS_JOB_TEMPLATE, HAS_CONTAINER",
                "category_3_storage": "CLAIMS_VOLUME, MOUNTS_VOLUME, USES_STORAGE_CLASS",
                "category_4_configuration": "LOADS_CONFIGMAP, USES_SECRET",
                "category_5_networking": "SELECTS_POD, ROUTES_TRAFFIC_TO",
                "category_6_rbac": "BINDS_ROLE, BINDS_SERVICE_ACCOUNT, USES_SERVICE_ACCOUNT",
                "category_7_autoscaling": "SCALES_RESOURCE",
            }
        }
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        
        print()
        print(f"   💾 Execution log saved to: {report_path} (overwritten)")